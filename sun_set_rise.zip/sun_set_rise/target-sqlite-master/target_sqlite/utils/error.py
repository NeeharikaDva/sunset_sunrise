class SchemaUpdateError(Exception):
    """Exception for when a requested Schema Update is invalid."""

    pass
